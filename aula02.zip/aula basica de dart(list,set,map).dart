void main(){
  //lista <tipo de dado>
  List<String> listaNomes = ["Cleber", "Jadson", "Neima"];
  //na list é utilizado []
  
  print ("---Lista dos Nomes---");
  print(listaNomes);
  
  //acessar itens da coleção 
  print("primeiro nome: ${listaNomes[0]}");
   print("segundo nome: ${listaNomes[1]}");
  
  ///set <tipo de dado>
  Set<String> cores ={
  "Azul", "verde", "Amarelo"
  }; ///usamos {} 
  print ("---Lista de Cores---");
  print(cores);
  
  //map <os tipos de dados que serão utilizados no argumento>
  
  Map<String,String> idade ={
    "Cleber" : "25",
    "Jadson": "99",
    "Neima" : "30"
  };
  print("--Lista de Idade--");
  print(idade);
}
