///mutuabilidade basica

void main(){
  //var - variavel pode ser reatribuida
  var nomes = ["joão", "julio", "luiz"];
  print(nomes);
  print(nomes.runtimeType);
  nomes = ["jefersom"];
  print(nomes);
  
  
    var id = {1, 2, 3};
  print(id.runtimeType);
  
  var idade = {"joão" : 32, "julio" : 72, "luiz" : 23 };
  print(idade.runtimeType);
  
  ///podemos ver que ao executar com runtimeType ele "descobre" que utilizando[] é uma list e o tipo de dado, utilizando {} ele descobre que é map e os tipo de dado e ao utilizar {"argumento" : argumento} ele descobre que é um map e ainda por cima descobre os dados do argumento
  
  //final -- variavel nao pode ser reatribuida, mas pode adicionar
    final nomez = ["joão", "julio", "luiz"];
  print(nomez);
  print(nomez.runtimeType);
  nomez.add("klebao");
  print(nomez);
  
  
  //const nao permite atribuição de novos valores, dito isso nao podemos fazer o nomes2.add("")
  
  const nomes2 = ["bruno", "mario"];
  print(nomes2);
  print(nomes2.runtimeType);

  ///dynamic o tipo de dado que permite utilizar int, string e boolean
  
  List<dynamic> valores = ["joão", 3, true, false, "neymar", 123123];
  print(valores[2]);
  print(valores[0]);
  print(valores.runtimeType);
}